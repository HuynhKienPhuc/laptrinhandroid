package com.example.bai_thuc_hanh1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {
    int requestcode = 222;
    EditText us2, pw2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout3);
        us2 = findViewById(R.id.us2);
        pw2 = findViewById(R.id.pw2);
    }

    public void SIGNIN(View view)
    {
        Intent i = getIntent();
        i.putExtra("US", us2.getText().toString());
        i.putExtra("PW", pw2.getText().toString());
        setResult(RESULT_OK, i);
        this.finish();
    }

    public void Cancel(View view) {
        Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
        startActivityForResult(i, requestcode);
    }
}