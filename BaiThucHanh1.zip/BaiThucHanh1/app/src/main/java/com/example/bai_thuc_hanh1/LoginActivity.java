package com.example.bai_thuc_hanh1;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    EditText us1, pw1;
    int requestcode = 111;
    ActivityResultLauncher<Intent> activityResultLauncher;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout2);

        // anh xa
        us1 = findViewById(R.id.us1);
        pw1 = findViewById(R.id.pw1);

        activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if(result.getResultCode() == RESULT_OK)
                {
                    Intent data = result.getData();
                    us1.setText(data.getStringExtra("US"));
                    pw1.setText(data.getStringExtra("PW"));
                }
            }
        });
    }

    public  void Register(View view)
    {
        Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
        activityResultLauncher.launch(i);
    }
}